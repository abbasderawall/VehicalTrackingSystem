﻿namespace VehicleTracking.Application.Modules.Models
{
	public class VehicleTrackingRecordViewModel : TrackingRecordViewModel
	{
		public string VehicleCode { get; set; }
	}   
}
