﻿namespace VehicleTracking.Application.Infrastructure
{
	public abstract class BaseRequest
	{
		public string Token { get; set; }
	}
}
   