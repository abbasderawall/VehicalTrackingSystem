﻿using System;

namespace VehicleTracking.Domain.Exceptions
{
	public class InvalidEmail : Exception
	{
		public InvalidEmail(string email)
			: base($"Email \"{email}\" is invalid.")
		{
		}
	}
}
