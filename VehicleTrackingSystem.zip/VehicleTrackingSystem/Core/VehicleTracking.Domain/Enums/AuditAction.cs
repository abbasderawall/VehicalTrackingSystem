﻿namespace VehicleTracking.Domain.Enums
{
	public enum AuditAction
	{
		Create,
		Update,
		Delete
	}

}
